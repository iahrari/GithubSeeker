package com.example.retrofitproject

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.util.Log
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val job = Job()
    private lateinit var adapter: ListAdapter
    private val scope = CoroutineScope(Dispatchers.Main + job)


    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler.layoutManager = GridLayoutManager(this, 2)
        adapter = ListAdapter()
        recycler.adapter = adapter

        val token = getSharedPreferences("token", Context.MODE_PRIVATE).getString("token", "")

        if (token == "" && intent.data == null) {
            getAuthorizeCode()

        } else if (token != "" && !intent?.data.toString().startsWith(RetrofitInterface.redirectURL))
            getRepos(token!!)

    }

    override fun onResume() {
        super.onResume()
        scope.launch {
            val uri = intent.data
            if (uri != null && uri.toString().startsWith(RetrofitInterface.redirectURL)) {
                try {
                    val response =
                        client.getAccessTokenAsync(
                            RetrofitInterface.clientId,
                            RetrofitInterface.clientSecret,
                            uri.getQueryParameter("code")!!
                        )

                    if (response.isSuccessful) {
                        val accessToken = response.body()
                        getSharedPreferences("token", Context.MODE_PRIVATE)
                            .edit()
                            .putString("token", accessToken!!.accessToken)
                            .apply()

                        getRepos(accessToken.accessToken)
                    } else
                        processResponseCode(response.code())

                } catch (t: Throwable) {
                    Log.i("logAuthProblem", t.message)
                }
            }
        }
    }

    private fun getRepos(accessToken: String) {

        scope.launch {
            try {
                val response = client.getReposAsync("token $accessToken")
                if (response.isSuccessful) {
                    adapter.submitList(response.body())
                } else
                    processResponseCode(response.code())

            } catch (t: Throwable) {
                Log.i("logRepoProblemCatch", t.message)
            }
        }
    }

    private fun processResponseCode(code: Int){
        when(code) {
            401 -> getAuthorizeCode().apply {
                Toast.makeText(this@MainActivity, "Failed to logIn", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun getAuthorizeCode() {
        startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://github.com/login/oauth/authorize?client_id=${RetrofitInterface.clientId}&scope=repo")
            )
        )
    }
}