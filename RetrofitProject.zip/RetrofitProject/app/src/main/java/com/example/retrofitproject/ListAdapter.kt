package com.example.retrofitproject

import android.support.v7.recyclerview.extensions.ListAdapter
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.retrofitproject.ListAdapter.MVHolder
import kotlinx.android.synthetic.main.recycler_item.view.*

class ListAdapter: ListAdapter<Repo, MVHolder>(DiffUtil()){

    override fun onCreateViewHolder(group: ViewGroup, itemType: Int): MVHolder {
        return MVHolder(LayoutInflater.from(group.context).inflate(R.layout.recycler_item, group,false))
    }

    override fun onBindViewHolder(holder: MVHolder, position: Int) {
        val data = getItem(position)
        holder.view.repo_name.text = data.name
        holder.view.repo_language.text = data.language
        holder.view.repo_description.text = data.description
    }

    class MVHolder(val view: View): RecyclerView.ViewHolder(view)
    class DiffUtil: android.support.v7.util.DiffUtil.ItemCallback<Repo>(){
        override fun areItemsTheSame(p0: Repo, p1: Repo): Boolean {
            return p0 == p1
        }

        override fun areContentsTheSame(p0: Repo, p1: Repo): Boolean {
            return p0 == p1
        }

    }
}